# Grocery App

<p align="center">
<img src="https://img.shields.io/badge/kotlin-%237F52FF.svg?style=for-the-badge&logo=kotlin&logoColor=white"/>

<img src="https://img.shields.io/badge/Android%20Studio-3DDC84.svg?style=for-the-badge&logo=android-studio&logoColor=white"/>
</p>

This app works as reminder while we are going to market and forgot about the things. You can create the list of such items and also track the cost and quantity.

---
## Quick Overview

You should see something like this now:

![App Overview](https://firebasestorage.googleapis.com/v0/b/fir-e1cc4.appspot.com/o/grocerycarT.png?alt=media&token=693a2c3a-1ada-4701-b974-7076f6cac25f)

---

## Simple Running of this project

Clone this repository and open it in android studio

* Please make sure that android studio is already installed in your system.

---

<div align="center">
<i>Other places you can find me:</i><br> 
<br>
<a href="https://www.linkedin.com/in/sagar-vashnav/" target="_blank"><img src="https://img.shields.io/badge/linkedin-%230077B5.svg?style=for-the-badge&logo=linkedin&logoColor=white" alt="LinkedIn"></a>
</div>
